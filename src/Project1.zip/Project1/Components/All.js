import Mid from "./Mid";
import Top from "./Top";
import About from "./About";
import Interests from "./Interests";
import Footer from "./Footer";
export default function All(){
    return(
        <div className="all">
            <Top/>
            <Mid/>
            <About/>
            <Interests/>
            <Footer/>
        </div>
    )
}
export default function Mid(){
    return (
        <div className="Mid--div">
            <h1>Laura Smith</h1>
            <h2>Fontend Developer</h2>
            <h4>laurasmith.website</h4>
        </div>
    )
}
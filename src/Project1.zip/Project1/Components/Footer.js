export default function Footer(){
    return (
        <div className="Footer--div">
            <ul>
                <li><img  src= {require('../Pictures/Twitter.png')}/></li>
                <li><img  src= {require('../Pictures/Facebook.png')}/></li>
                <li><img  src= {require('../Pictures/Insta.png')}/></li>
                <li><img  src= {require('../Pictures/Linkedin.png')}/></li>
                <li><img  src= {require('../Pictures/GitHub.png')}/></li>
            </ul>
        </div>
    )
} 
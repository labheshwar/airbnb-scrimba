export default function MainContent(){
    return (
        <header className="top">
            <img src={require('../Pictures/Profile.png')}/>
        </header>
    )
}
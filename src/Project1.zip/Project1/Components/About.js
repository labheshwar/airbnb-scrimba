export default function About(){
    return (
        <div className="About--div">
            <h2>About</h2>
            <p>
                I am a frontend Developer with a particular interest<br/>
                in making things simple and automating daily tasks.<br/>
                I try to keep up with security and best practices,<br/>
                and am always looking for new things to learn.
            </p>
        </div>
    )
}
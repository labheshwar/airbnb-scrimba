export default function Interests(){
    return (
        <div className="Interests--div">
            <h2>Interests</h2>
            <p>
                Food expert,Music Scholar,Reader,Interenet fanatic,<br/>
                bacon buff,Enterpreneur,Travel geek,Pop culture ninja,<br/>
                Coffee fanatic.
            </p>
        </div>
    )
}